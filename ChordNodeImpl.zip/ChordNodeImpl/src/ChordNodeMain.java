import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


/**
 * @author Manik, Neha
 *
 * This is the entry point where the main function decides
 * whether the Server instance is a gateway node or node and
 * then makes call to appropriate class functions (GatewayThread or ChordNodeAction)
 *
 */

public class ChordNodeMain {
	static ChordNode node;
	String ipAddress;
	int port;
	static Map<Integer, ChordNode> Membership_Table;
	static boolean x = false;
	static boolean updateHBTable = false; //flag will be set to true if new node joins
	synchronized public static boolean isUpdateHBTable() { //ensures when update action is performed, get function cannot be called
		return updateHBTable;
	}

	synchronized public static void setUpdateHBTable(boolean updateHBTable) { //ensures when update action is performed, get function cannot be called
		ChordNodeMain.updateHBTable = updateHBTable;
	}
	static boolean updateListenerTable = false; //flag set to true when new node joins in
	synchronized public static boolean isUpdateListenerTable() {
		return updateListenerTable;
	}

	synchronized public static void setUpdateListenerTable(boolean updateListenerTable) {
		ChordNodeMain.updateListenerTable = updateListenerTable;
	}
	/* 
	 * 1.GatewayThread called if the Server instance is the gateway node matching ip address
	 * 2. ChordNodeAction called for any new joining node whose Ip Address does not match the Gateway 
	 * IP address
	 */
	
	public ChordNodeMain(String ipAddress, int port){
		node = new ChordNode(ipAddress, port);
	}
	
	public static void main(String args[]) throws UnknownHostException, SocketException{
		System.out.println("["+ChordNodeMain.class.getSimpleName() + "] : " +"Starting program..........");
		InetAddress ipAddress = InetAddress.getLocalHost();
		
		String ipAddress_str = ipAddress.getHostAddress();
		System.out.println("["+ChordNodeMain.class.getSimpleName() + "] : " +
		"IP Address of the current Server Node::" +ipAddress.getHostAddress().toString());
		System.out.println("["+ChordNodeMain.class.getSimpleName() + "] : " +
		"Checking if the current Server IPAddress is the designated Gateway Node Address");
		new ChordNodeMain(ipAddress_str, Constants.ChordNode_TCPPort);
		Thread chordActionThread;
		System.out.println("["+ChordNodeMain.class.getSimpleName() + "] : " +"Welcome to the Network");
		
		//x = true;
		//if(x){
		if(ifGatewayNode(ipAddress_str)){
			x=true;
			createMembershipTable();
			runGatewayThread(ipAddress,Constants.GatewayTCPPort);
			Thread heartBeater = new Thread(new HeartBeater());
			heartBeater.start();
			Thread Listener = new Thread(new Listener());
			Listener.start();
			
		}else{
			chordActionThread = new Thread(new ChordNodeAction( Constants.GatewayNodeAddress,Constants.GatewayTCPPort ));
			chordActionThread.start();
		}
	}
	
	/* ifGatewayNode returns true if new node ipaddress matches the designated gateway node 
	 * IP address, else returns false
	 */
	private static boolean ifGatewayNode(String ipAddress){
		if(Constants.GatewayNodeAddress.equals(ipAddress)){
			System.out.println("["+ChordNodeMain.class.getSimpleName() + "] : " +"The instance is a gateway node");
			return true;
		}
		else
			return false;
	}
	
	/* initiate the gateway thread if the incoming node ip address matches the designated
	 * IP address of the gateway node
	 */
	private static void runGatewayThread(InetAddress ipAddress, int port){
		Thread gateway = new Thread(new GatewayThread(ipAddress, port ));
		gateway.start();
	}
	
	//Called once when the gateway node is initiated for the first time 
	private static void createMembershipTable(){
		Membership_Table = new HashMap<Integer, ChordNode>();
		if(node.getHashedId() != 0){
			System.out.println("["+ChordNodeMain.class.getSimpleName() + "] : " +"Adding data to the Finger Table");
			Membership_Table.put(node.getHashedId(), node);
		}
		System.out.println("["+ChordNodeMain.class.getSimpleName() + "] : " + 
		"Current Element in the Membership Table::" + Membership_Table.get(node.getHashedId()).hashKey);
	}

}
